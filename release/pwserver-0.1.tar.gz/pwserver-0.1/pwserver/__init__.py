# --encoding:utf8--

"""

aim to build a 'real' web server from the very beginning in python

[PyWebServer]: https://github.com/laszo/PyWebServer
"""

from launch import launch
from framework import application
